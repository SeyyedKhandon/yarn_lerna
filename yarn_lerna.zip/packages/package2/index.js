const commonFunction = require("@yarn_lerna/package1");
commonFunction();
